# Catatan Keputusan (Decision Log)

Catatan keputusan desain penting. Entri TERBARU di atas. Jangan hapus
entri lama; cukup tambahkan yang baru. Format tiap entri: tanggal,
keputusan, dan alasan singkat. Baca file ini sebelum mengubah desain.

---

## 2026-07-05 — Fondasi awal

- **Model data relasional (Supabase/PostgreSQL).** Tabel: `menus`,
  `menu_items`, `shopping_lists`, `shopping_list_items`. Alasan: data
  belanja penuh hubungan "satu punya banyak", cocok untuk SQL.

- **Template hanya menyalin, tidak mengikat.** Menambah template ke daftar
  menyalin itemnya ke `shopping_list_items`. Alasan: agar edit per sesi
  (ubah jumlah, tandai sudah punya) tidak merusak template dan riwayat
  tetap akurat.

- **Jumlah = takaran atau uang.** `quantity` + `unit` untuk takaran (mis.
  "1 ons", "1/2 kg"), `budget` untuk beli-berdasar-uang (mis. "sayur
  5rb" = 5000), `note` untuk alternatif ("atau 1/4 kg"). Alasan:
  instruksi belanja nyata tidak selalu berupa berat/jumlah.

- **Status item: need / have / cart.** Item "sudah punya di rumah" diberi
  status `have` (tetap tampil, dilewati), bukan dihapus. Alasan: menjaga
  template tetap lengkap sekaligus mengecualikan item dari belanja kali ini.

- **Riwayat = daftar berstatus 'done'.** Tidak ada tabel riwayat terpisah.
  Alasan: item daftar sudah berupa salinan bebas, jadi daftar selesai
  otomatis menjadi catatan riwayat yang akurat.

- **Autentikasi diperlukan (magic link / Google).** Alasan: RLS berbasis
  `auth.uid()` menjaga privasi, dan login membuat data bisa diakses dari
  HP maupun laptop ("buka di mana saja").

- **Berbagi template pakai model salin.** Kolom `share_code` + fungsi
  `import_shared_menu()` (security definer). Alasan: penerima mendapat
  salinan miliknya sendiri tanpa bisa mengakses data lain si pemilik;
  cocok untuk skenario pindah/berpisah rumah.

- **PWA + offline.** Aplikasi dibuat sebagai PWA dengan service worker,
  sinkron "penulisan terakhir menang" berdasarkan `updated_at`; `id`
  berupa `uuid` agar bisa dibuat saat offline. Alasan: sinyal di pasar
  sering buruk.

- **Konteks proyek disimpan di repositori.** `CLAUDE.md` di akar + folder
  `docs/`. Alasan: Claude tidak mengingat percakapan antar sesi, jadi
  ingatan harus hidup di dalam proyek.
